"use client"

import { motion, useScroll, useTransform } from "framer-motion"
import { useRef } from "react"
import { ArrowDown, Play, ChevronRight, Sparkles } from "lucide-react"
import MagneticButton from "../components/MagneticButton"
import { useContent } from "../components/ContentProvider"
import SafeImage from "../components/SafeImage"

export default function Hero() {
  const { content } = useContent()
  const ref = useRef(null)
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"]
  })

  const y = useTransform(scrollYProgress, [0, 1], [0, 120])
  const opacity = useTransform(scrollYProgress, [0, 0.8], [1, 0])
  const scale = useTransform(scrollYProgress, [0, 1], [1, 0.95])

  const words = content.heroTitle.split(" ")
  const lastWord = words.pop() || "Solutions"
  const titleWords = words

  const scrollToAbout = (e: React.MouseEvent) => {
    e.preventDefault()
    document.getElementById("about")?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <section
      id="home"
      ref={ref}
      className="relative min-h-[85svh] sm:min-h-screen flex items-center justify-center overflow-hidden pt-20 pb-8 sm:pb-12"
    >
      {/* Background Effects */}
      <div className="absolute inset-0 bg-gradient-to-b from-navy-950 via-navy-950 to-navy-900" />
      <div className="absolute inset-0 bg-grid opacity-30 sm:opacity-40" />

      <motion.div
        style={{ y, opacity, scale }}
        className="absolute top-1/4 left-1/4 w-64 h-64 sm:w-96 sm:h-96 bg-electric/20 rounded-full blur-[100px] sm:blur-[120px]"
      />
      <motion.div
        style={{ y: useTransform(scrollYProgress, [0, 1], [0, -60]) }}
        className="absolute bottom-1/4 right-1/4 w-56 h-56 sm:w-80 sm:h-80 bg-electric-light/10 rounded-full blur-[80px] sm:blur-[100px]"
      />

      {/* Floating Orbs - reduced on mobile */}
      <div className="hidden sm:block absolute inset-0 overflow-hidden pointer-events-none" aria-hidden="true">
        {[...Array(5)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute rounded-full bg-electric/20 blur-xl"
            style={{
              width: Math.random() * 200 + 100,
              height: Math.random() * 200 + 100,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`
            }}
            animate={{
              y: [0, -30, 0],
              x: [0, 20, 0],
              opacity: [0.1, 0.3, 0.1]
            }}
            transition={{
              duration: 8 + i * 2,
              repeat: Infinity,
              ease: "easeInOut",
              delay: i * 0.5
            }}
          />
        ))}
      </div>

      <div className="relative z-10 max-w-[1400px] mx-auto section-padding w-full">
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-20 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="text-center lg:text-left"
          >
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-card mb-4 sm:mb-6"
            >
              <Sparkles className="w-4 h-4 text-electric" />
              <span className="text-sm text-white/80">{content.heroSubtitle}</span>
            </motion.div>

            <h1 className="text-3xl sm:text-5xl md:text-6xl lg:text-7xl font-bold leading-tight mb-4 sm:mb-6 text-balance">
              {titleWords.map((w, i) => <span key={i}>{w} </span>)}
              <span className="text-gradient">{lastWord}</span>
            </h1>

            <p className="text-sm sm:text-base sm:text-lg text-white/70 max-w-2xl mx-auto lg:mx-0 mb-6 sm:mb-8 leading-relaxed">
              {content.heroDescription}
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3 sm:gap-4 mb-6 sm:mb-10">
              <MagneticButton href="#divisions" className="w-full sm:w-auto" ariaLabel={content.heroCtaPrimary}>
                {content.heroCtaPrimary}
                <ChevronRight className="ml-2 w-4 h-4" />
              </MagneticButton>
              <MagneticButton href="#contact" variant="outline" className="w-full sm:w-auto" ariaLabel={content.heroCtaSecondary}>
                {content.heroCtaSecondary}
              </MagneticButton>
            </div>

            <div className="hidden sm:flex flex-wrap items-center justify-center lg:justify-start gap-6 text-sm text-white/50">
              <span className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-electric" />
                AI-First Development
              </span>
              <span className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-electric" />
                Enterprise Architecture
              </span>
              <span className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-electric" />
                Global Delivery
              </span>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="relative flex items-center justify-center"
          >
            <div className="relative w-48 h-48 sm:w-64 sm:h-64 lg:w-[420px] lg:h-[420px]">
              <div className="absolute inset-0 bg-gradient-to-br from-electric/30 to-transparent rounded-full blur-3xl" />

              <motion.div
                animate={{ rotateY: [0, 360] }}
                transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
                className="relative w-full h-full rounded-3xl overflow-hidden shadow-2xl shadow-electric/20 will-change-transform"
                style={{ transformStyle: "preserve-3d" }}
              >
                <SafeImage
                  src="./logo.png"
                  alt="KADS LABS - Building Smarter Solutions"
                  fill
                  containerClassName="w-full h-full"
                />
              </motion.div>

              {/* Orbiting Elements - smaller on mobile */}
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
                className="absolute inset-0 rounded-full border border-white/5"
                aria-hidden="true"
              />
              <motion.div
                animate={{ rotate: -360 }}
                transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
                className="absolute -inset-4 sm:-inset-8 rounded-full border border-electric/10"
                aria-hidden="true"
              />

              {[0, 72, 144, 216, 288].map((deg, i) => (
                <motion.div
                  key={i}
                  animate={{ rotate: 360 }}
                  transition={{ duration: 20 + i * 5, repeat: Infinity, ease: "linear" }}
                  className="hidden sm:block absolute top-1/2 left-1/2 w-full h-full"
                  style={{ transformOrigin: "center" }}
                  aria-hidden="true"
                >
                  <div
                    className="absolute w-2.5 h-2.5 sm:w-3 sm:h-3 rounded-full bg-electric shadow-lg shadow-electric/50"
                    style={{
                      transform: `rotate(${deg}deg) translateX(${i % 2 === 0 ? 110 : 150}px)`
                    }}
                  />
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1, duration: 0.5 }}
        className="absolute bottom-4 sm:bottom-8 left-1/2 -translate-x-1/2"
      >
        <a
          href="#about"
          onClick={scrollToAbout}
          className="flex flex-col items-center gap-1 sm:gap-2 text-white/50 hover:text-electric transition-colors"
          aria-label="Scroll to about section"
        >
          <span className="text-[10px] sm:text-xs uppercase tracking-widest">Scroll</span>
          <motion.div
            animate={{ y: [0, 6, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          >
            <ArrowDown className="w-4 h-4 sm:w-5 sm:h-5" />
          </motion.div>
        </a>
      </motion.div>
    </section>
  )
}
