"use client"

import dynamic from "next/dynamic"
import { useEffect } from "react"
import LoadingScreen from "./components/LoadingScreen"
import ScrollProgress from "./components/ScrollProgress"
import Navbar from "./components/Navbar"
import ParticleBackground from "./components/ParticleBackground"
import CursorGlow from "./components/CursorGlow"
import Hero from "./sections/Hero"
import Footer from "./sections/Footer"
import MetadataUpdater from "./components/MetadataUpdater"
import PWARegister from "./components/PWARegister"
import ErrorBoundary from "./components/ErrorBoundary"
import { trackEvent } from "./components/admin/AnalyticsPanel"

const About = dynamic(() => import("./sections/About"), { loading: () => null })
const FounderTeam = dynamic(() => import("./sections/FounderTeam"), { loading: () => null })
const KadMedia = dynamic(() => import("./sections/KadMedia"), { loading: () => null })
const KadTech = dynamic(() => import("./sections/KadTech"), { loading: () => null })
const Portfolio = dynamic(() => import("./sections/Portfolio"), { loading: () => null })
const Testimonials = dynamic(() => import("./sections/Testimonials"), { loading: () => null })
const FAQ = dynamic(() => import("./sections/FAQ"), { loading: () => null })
const Blogs = dynamic(() => import("./sections/Blogs"), { loading: () => null })
const Careers = dynamic(() => import("./sections/Careers"), { loading: () => null })
const Contact = dynamic(() => import("./sections/Contact"), { loading: () => null })

export default function Home() {
  useEffect(() => {
    if (typeof window === "undefined") return
    trackEvent("page_view", { path: window.location.pathname, referrer: document.referrer })
  }, [])

  return (
    <ErrorBoundary>
      <main className="relative bg-navy-950 min-h-screen">
        <LoadingScreen />
        <ScrollProgress />
        <Navbar />
        <ParticleBackground />
        <CursorGlow />
        <MetadataUpdater />
        <PWARegister />

        <Hero />
        <About />
        <FounderTeam />
        <KadMedia />
        <KadTech />
        <Portfolio />
        <Testimonials />
        <Blogs />
        <Careers />
        <FAQ />
        <Contact />
        <Footer />
      </main>
    </ErrorBoundary>
  )
}
