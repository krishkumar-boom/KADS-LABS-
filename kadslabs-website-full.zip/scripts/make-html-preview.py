#!/usr/bin/env python3
"""Create a self-contained static HTML preview from the Next.js export."""
import base64
from pathlib import Path
from bs4 import BeautifulSoup
from PIL import Image

ROOT = Path(__file__).resolve().parent.parent
DIST = ROOT / "dist"
OUT = ROOT / "kadslabs-website.html"


def mime_for(path: Path) -> str:
    ext = path.suffix.lower()
    return {
        ".png": "image/png",
        ".svg": "image/svg+xml",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".gif": "image/gif",
        ".webp": "image/webp",
    }.get(ext, "application/octet-stream")


def to_data_uri(path: Path) -> str:
    data = path.read_bytes()
    if path.suffix.lower() == ".svg":
        try:
            text = data.decode("utf-8")
            encoded = (
                text.replace("%", "%25")
                .replace('"', "%22")
                .replace("#", "%23")
                .replace("<", "%3C")
                .replace(">", "%3E")
                .replace("&", "%26")
                .replace("\n", "%0A")
                .replace("\r", "")
            )
            return f"data:image/svg+xml;charset=utf-8,{encoded}"
        except UnicodeDecodeError:
            pass
    return f"data:{mime_for(path)};base64,{base64.b64encode(data).decode('ascii')}"


def make_resized_logo(src: Path, dest: Path, size: int = 128) -> None:
    img = Image.open(src).convert("RGBA")
    img.thumbnail((size, size), Image.Resampling.LANCZOS)
    img.save(dest, "PNG", optimize=True)


def main():
    if not DIST.exists():
        raise SystemExit(f"dist/ folder not found at {DIST}")

    soup = BeautifulSoup((DIST / "index.html").read_text(encoding="utf-8"), "lxml")

    # Use a small logo preview so the single HTML file stays lightweight
    logo_src = DIST / "logo.png"
    preview_logo = ROOT / "logo-preview.png"
    make_resized_logo(logo_src, preview_logo, size=128)
    logo_data = to_data_uri(preview_logo)

    # Inline CSS
    for link in list(soup.find_all("link", rel="stylesheet")):
        href = link.get("href") or ""
        if href.startswith("./") or href.startswith("/"):
            css_path = DIST / href.lstrip("./").lstrip("/")
            if css_path.exists():
                style = soup.new_tag("style")
                style.string = css_path.read_text(encoding="utf-8")
                link.replace_with(style)
            else:
                link.decompose()

    # Remove preloads and manifest
    for link in list(soup.find_all("link", rel="preload")):
        link.decompose()
    for link in list(soup.find_all("link", rel="manifest")):
        link.decompose()

    # Replace local image/link assets with data URIs. Use the small logo preview
    # for every logo.png reference so the file does not bloat.
    for tag in soup.find_all(["link", "img"]):
        attr = "href" if tag.name == "link" else "src"
        val = tag.get(attr) or ""
        if not val.startswith("./") and not val.startswith("/"):
            continue
        asset_path = DIST / val.lstrip("./").lstrip("/")
        if not asset_path.exists():
            continue
        if asset_path.name == "logo.png":
            tag[attr] = logo_data
        else:
            tag[attr] = to_data_uri(asset_path)

    # Remove all scripts (Next.js hydration, chunks, etc.) except JSON-LD.
    for script in list(soup.find_all("script")):
        if script.get("type") == "application/ld+json":
            continue
        script.decompose()

    # Force the loading overlay off and reveal animated elements.
    extra = soup.new_tag("style")
    extra.string = """
        .js-loading { display: none !important; }
        html, body { scroll-behavior: smooth; }
        [style*="opacity:0"] { opacity: 1 !important; transform: none !important; }
        [style*="transform:translateY(20px)"] { transform: none !important; }
        [style*="transform:scale(0.8)"] { transform: none !important; }
        [style*="transform:translateY(-100px)"] { transform: none !important; }
    """
    if soup.head:
        soup.head.append(extra)
    if soup.title:
        soup.title.string = "KADS LABS | Static HTML Preview"

    OUT.write_text("<!DOCTYPE html>\n" + str(soup), encoding="utf-8")
    print(f"Created {OUT} ({OUT.stat().st_size:,} bytes)")


if __name__ == "__main__":
    main()
