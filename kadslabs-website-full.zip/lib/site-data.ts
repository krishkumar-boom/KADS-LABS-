import { safeStorage } from "./storage"

export type ContentType = "homepage" | "about" | "leadership" | "team" | "services" | "divisions" | "portfolio" | "blogs" | "careers" | "testimonials" | "faqs" | "contact" | "social" | "navigation" | "footer" | "seo" | "analytics" | "settings"

export interface SiteContent {
  heroTitle: string
  heroSubtitle: string
  heroDescription: string
  heroCtaPrimary: string
  heroCtaSecondary: string
  heroVideoLabel: string
  aboutTitle: string
  aboutDescription: string
  mission: string
  vision: string
  mediaTitle: string
  mediaDescription: string
  techTitle: string
  techDescription: string
  contactTitle: string
  contactDescription: string
  founderNote: string
  metaTitle: string
  metaDescription: string
  updatedAt?: number
}

export interface Leader {
  id: string
  name: string
  designation: string
  bio: string
  photo: string
  skills: string[]
  social: {
    linkedin?: string
    twitter?: string
    instagram?: string
    website?: string
    email?: string
  }
  experience: {
    company: string
    role: string
    period: string
    description: string
  }[]
  order: number
  featured?: boolean
}

export interface TeamMember {
  id: string
  name: string
  role: string
  division: string
  bio: string
  photo: string
  skills: string[]
  social: {
    linkedin?: string
    twitter?: string
    instagram?: string
  }
  order: number
}

export interface Division {
  id: string
  name: string
  title: string
  subtitle: string
  description: string
  longDescription?: string
  color: "purple" | "blue" | "cyan" | "emerald" | "orange" | "pink" | "slate"
  accentColor: string
  cta: string
  ctaHref: string
  order: number
  featured?: boolean
}

export interface Service {
  id: string
  title: string
  description: string
  icon: string
  divisionId: string
  featured?: boolean
  order: number
}

export interface ProcessStep {
  id: string
  step: string
  title: string
  description: string
  divisionId: string
  order: number
}

export interface Industry {
  id: string
  title: string
  icon: string
  divisionId: string
  order: number
}

export interface PortfolioItem {
  id: string
  title: string
  category: string
  description: string
  stats: string
  details: string
  image?: string
  divisionId: string
  featured?: boolean
  order: number
  gradient?: string
}

export interface BlogPost {
  id: string
  title: string
  slug: string
  excerpt: string
  content: string
  author: string
  publishedAt: string
  image?: string
  tags: string[]
  divisionId?: string
  status: "published" | "draft"
  order: number
}

export interface Career {
  id: string
  title: string
  department: string
  location: string
  type: "full-time" | "part-time" | "contract" | "internship" | "remote"
  description: string
  requirements: string[]
  benefits?: string[]
  createdAt: string
  active: boolean
  order: number
}

export interface Testimonial {
  id: string
  name: string
  role: string
  text: string
  rating: number
  division: string
  company?: string
  image?: string
  order: number
}

export interface FAQ {
  id: string
  question: string
  answer: string
  category: string
  order: number
}

export interface NavLink {
  id: string
  label: string
  href: string
  order: number
  visible: boolean
}

export interface FooterColumn {
  title: string
  links: { label: string; href: string }[]
}

export interface FooterData {
  brandDescription: string
  newsletterText: string
  copyright: string
  columns: FooterColumn[]
  legalLinks: { label: string; href: string }[]
}

export interface ContactInfo {
  phone: string
  email: string
  website: string
  address: string
  mapEmbedUrl?: string
  workingHours?: string
}

export interface SocialLink {
  id: string
  platform: string
  url: string
  icon: string
  order: number
}

export interface SEO {
  metaTitle: string
  metaDescription: string
  keywords: string
  ogImage?: string
  canonical?: string
  twitterCard?: string
}

export interface WebsiteSettings {
  siteName: string
  tagline: string
  logoUrl?: string
  faviconUrl?: string
  themeColor: string
  maintenanceMode: boolean
  allowPublicContact: boolean
  defaultRole: string
  adminEmails: string
  contactEmail: string
  notificationEmail: string
}

export interface AnalyticsSummary {
  totalVisits: number
  pageViews: number
  leads: number
  lastUpdated: string
  topPages: { path: string; views: number }[]
}

export interface MediaFile {
  id: string
  name: string
  type: "image" | "video" | "pdf" | "zip" | "document" | "other"
  url: string
  size: number
  mimeType: string
  folder: string
  createdAt: string
  updatedAt: string
  metadata?: Record<string, any>
}

export interface ContactSubmission {
  id: string
  name: string
  email: string
  phone: string
  company?: string
  service: string
  budget: string
  message: string
  status: "new" | "contacted" | "qualified" | "proposal" | "won" | "lost"
  source: string
  assignedTo?: string
  notes: Note[]
  createdAt: string
  updatedAt: string
  userId?: string
}

export interface Note {
  id: string
  text: string
  author: string
  createdAt: string
}

export interface UserProfile {
  id: string
  fullName: string
  company: string
  phone: string
  role: string
  avatarUrl?: string
  email: string
  emailVerified: boolean
  createdAt: string
  updatedAt: string
}

export interface UserRole {
  id: string
  userId: string
  role: "super_developer" | "founder" | "director" | "admin" | "user"
  createdAt: string
  updatedAt: string
}

export interface SiteData {
  siteContent: SiteContent
  leadership: Leader[]
  team: TeamMember[]
  divisions: Division[]
  services: Service[]
  process: ProcessStep[]
  industries: Industry[]
  divisionPortfolio: PortfolioItem[]
  divisionTestimonials: Testimonial[]
  portfolio: PortfolioItem[]
  blogs: BlogPost[]
  careers: Career[]
  testimonials: Testimonial[]
  faqs: FAQ[]
  navigation: NavLink[]
  footer: FooterData
  contact: ContactInfo
  social: SocialLink[]
  seo: SEO
  settings: WebsiteSettings
  analytics: AnalyticsSummary
}

export const defaultContent: SiteContent = {
  heroTitle: "Building Smarter Solutions",
  heroSubtitle: "Enterprise Technology Partner",
  heroDescription: "KADS LABS builds innovative software products, AI-powered solutions, websites, mobile applications, SaaS platforms, automation systems, and enterprise digital products that help businesses grow faster.",
  heroCtaPrimary: "Explore Divisions",
  heroCtaSecondary: "Contact Us",
  heroVideoLabel: "Watch Company Profile",
  aboutTitle: "We Engineer the Future",
  aboutDescription: "KADS LABS is a technology company built for the modern enterprise. We combine design, engineering, and artificial intelligence to deliver digital products that create measurable business impact.",
  mission: "To empower businesses with intelligent technology solutions that simplify complexity, automate operations, and accelerate growth. We believe every organization deserves access to world-class digital products without compromising on quality, security, or scalability.",
  vision: "To become a global technology leader recognized for building smarter solutions that shape industries. We envision a world where AI, automation, and human creativity work together to solve the most challenging business problems at scale.",
  mediaTitle: "Transforming Brands Into Digital Success",
  mediaDescription: "KADS MEDIA helps businesses build strong digital identities through branding, advertising, content creation, and performance marketing.",
  techTitle: "Engineering the Future Through Technology",
  techDescription: "KADS TECHNOLOGIES develops websites, mobile applications, AI solutions, SaaS products, cloud software, enterprise platforms, dashboards, automation systems, and scalable digital products.",
  contactTitle: "Let's Build Something Great",
  contactDescription: "Ready to transform your business? Get in touch with our team and start your next project.",
  founderNote: "Replace placeholder photos by uploading new images to the media library or through the Developer Control Centre.",
  metaTitle: "KADS LABS | Building Smarter Solutions",
  metaDescription: "KADS LABS builds innovative software products, AI-powered solutions, websites, mobile applications, SaaS platforms, automation systems, and enterprise digital products."
}

export const defaultLeadership: Leader[] = [
  {
    id: "shivam-gupta-ceo",
    name: "Shivam Gupta",
    designation: "Founder & CEO, KADS LABS",
    bio: "Founder and CEO of KADS LABS, driving the overall vision, innovation, and strategic growth across all divisions.",
    photo: "./team/shivam-gupta.svg",
    skills: ["Strategic Leadership", "Product Vision", "Enterprise Growth", "AI Strategy"],
    social: {
      linkedin: "https://www.linkedin.com/in/shivam-gupta-kadslabs",
      twitter: "https://twitter.com/shivamkadslabs"
    },
    experience: [
      { company: "KADS LABS", role: "Founder & CEO", period: "2020 - Present", description: "Built KADS LABS from the ground up into a multi-division technology company." }
    ],
    order: 1,
    featured: true
  },
  {
    id: "shivam-gupta-tech",
    name: "Shivam Gupta",
    designation: "Head, KADS TECHNOLOGIES",
    bio: "Head of KADS TECHNOLOGIES, overseeing product innovation, engineering delivery, and client success worldwide.",
    photo: "./team/shivam-gupta.svg",
    skills: ["Software Architecture", "Engineering Delivery", "AI Integration", "Cloud Infrastructure"],
    social: {
      linkedin: "https://www.linkedin.com/in/shivam-gupta-kadslabs",
      twitter: "https://twitter.com/shivamkadslabs"
    },
    experience: [
      { company: "KADS TECHNOLOGIES", role: "Head of Engineering", period: "2020 - Present", description: "Leading technical delivery across web, mobile, AI, and cloud projects." }
    ],
    order: 2,
    featured: true
  },
  {
    id: "ayush-jaiswal",
    name: "Ayush Jaiswal",
    designation: "Co-Founder & Director, KADS MEDIA",
    bio: "Co-Founder and Director of KADS MEDIA, leading branding, digital marketing, and creative strategy for global clients.",
    photo: "./team/ayush-jaiswal.svg",
    skills: ["Brand Strategy", "Digital Marketing", "Content Strategy", "Performance Marketing"],
    social: {
      linkedin: "https://www.linkedin.com/in/ayush-jaiswal-kadslabs",
      twitter: "https://twitter.com/ayushkadslabs"
    },
    experience: [
      { company: "KADS MEDIA", role: "Co-Founder & Director", period: "2020 - Present", description: "Scaled KADS MEDIA into a full-service digital marketing division." }
    ],
    order: 3,
    featured: true
  },
  {
    id: "sudheer-maddheshiya",
    name: "Sudheer Maddheshiya",
    designation: "Co-Founder & Director, KADS MEDIA",
    bio: "Co-Founder and Director of KADS MEDIA, shaping creative strategy, brand storytelling, and media operations for clients worldwide.",
    photo: "./team/sudheer-maddheshiya.svg",
    skills: ["Creative Strategy", "Brand Storytelling", "Media Operations", "Content Production"],
    social: {
      linkedin: "https://www.linkedin.com/in/sudheer-maddheshiya-kadslabs",
      twitter: "https://twitter.com/sudheerkadslabs"
    },
    experience: [
      { company: "KADS MEDIA", role: "Co-Founder & Director", period: "2020 - Present", description: "Built KADS MEDIA's creative and media operations from the ground up." }
    ],
    order: 4,
    featured: true
  }
]

export const defaultTeam: TeamMember[] = defaultLeadership.map((leader) => ({
  id: leader.id,
  name: leader.name,
  role: leader.designation,
  division: leader.designation.includes("MEDIA") ? "KADS MEDIA" : leader.designation.includes("TECHNOLOGIES") ? "KADS TECHNOLOGIES" : "KADS LABS",
  bio: leader.bio,
  photo: leader.photo,
  skills: leader.skills,
  social: leader.social,
  order: leader.order
}))

export const defaultDivisions: Division[] = [
  {
    id: "kads-media",
    name: "KADS MEDIA",
    title: "KADS MEDIA",
    subtitle: "Division 01",
    description: "KADS MEDIA helps businesses build strong digital identities through branding, advertising, content creation, and performance marketing.",
    longDescription: "We transform brands into digital success stories with creative strategy, performance marketing, and content that converts.",
    color: "purple",
    accentColor: "#8b5cf6",
    cta: "Grow Your Brand With KADS MEDIA",
    ctaHref: "#contact",
    order: 1,
    featured: true
  },
  {
    id: "kads-tech",
    name: "KADS TECHNOLOGIES",
    title: "KADS TECHNOLOGIES",
    subtitle: "Division 02",
    description: "KADS TECHNOLOGIES develops websites, mobile applications, AI solutions, SaaS products, cloud software, enterprise platforms, dashboards, automation systems, and scalable digital products.",
    longDescription: "We engineer the future through modern technology, AI-powered systems, and cloud-native platforms that scale with your business.",
    color: "blue",
    accentColor: "#2563EB",
    cta: "Start Your Technology Project",
    ctaHref: "#contact",
    order: 2,
    featured: true
  }
]

export const defaultServices: Service[] = [
  // KADS MEDIA services
  { id: "sm-management", title: "Social Media Management", description: "Strategic content planning and community management", icon: "Megaphone", divisionId: "kads-media", order: 1 },
  { id: "fb-ads", title: "Facebook Ads", description: "Targeted campaigns that drive leads and sales", icon: "Facebook", divisionId: "kads-media", order: 2 },
  { id: "insta-ads", title: "Instagram Ads", description: "Visual storytelling for engagement and conversions", icon: "Instagram", divisionId: "kads-media", order: 3 },
  { id: "google-ads", title: "Google Ads", description: "High-intent search and display advertising", icon: "Search", divisionId: "kads-media", order: 4 },
  { id: "yt-marketing", title: "YouTube Marketing", description: "Video strategies that build brand authority", icon: "Youtube", divisionId: "kads-media", order: 5 },
  { id: "seo", title: "SEO", description: "Organic growth through technical and content SEO", icon: "TrendingUp", divisionId: "kads-media", order: 6 },
  { id: "brand-identity", title: "Brand Identity", description: "Cohesive brand systems and visual language", icon: "Palette", divisionId: "kads-media", order: 7 },
  { id: "logo-design", title: "Logo Design", description: "Memorable logos that define your brand", icon: "PenTool", divisionId: "kads-media", order: 8 },
  { id: "graphic-design", title: "Graphic Designing", description: "Creative visuals for digital and print media", icon: "ImageIcon", divisionId: "kads-media", order: 9 },
  { id: "poster-design", title: "Poster Designing", description: "Impactful promotional and event creatives", icon: "Sparkles", divisionId: "kads-media", order: 10 },
  { id: "video-editing", title: "Video Editing", description: "Professional editing for ads and content", icon: "Video", divisionId: "kads-media", order: 11 },
  { id: "reel-editing", title: "Reel Editing", description: "Short-form video content for social platforms", icon: "Clapperboard", divisionId: "kads-media", order: 12 },
  { id: "motion-graphics", title: "Motion Graphics", description: "Animated graphics that capture attention", icon: "Camera", divisionId: "kads-media", order: 13 },
  { id: "photography", title: "Photography", description: "Product and lifestyle photography services", icon: "UserCircle", divisionId: "kads-media", order: 14 },
  { id: "content-writing", title: "Content Writing", description: "SEO-optimized blogs, copies, and scripts", icon: "FileText", divisionId: "kads-media", order: 15 },
  { id: "influencer-marketing", title: "Influencer Marketing", description: "Strategic creator collaborations", icon: "Users", divisionId: "kads-media", order: 16 },
  { id: "lead-gen", title: "Lead Generation", description: "Qualified leads through paid and organic channels", icon: "Target", divisionId: "kads-media", order: 17 },
  { id: "analytics", title: "Analytics", description: "Data-driven insights and reporting", icon: "BarChart3", divisionId: "kads-media", order: 18 },
  { id: "performance-marketing", title: "Performance Marketing", description: "ROI-focused campaign management", icon: "Megaphone", divisionId: "kads-media", order: 19 },
  { id: "campaign-management", title: "Digital Campaign Management", description: "End-to-end campaign execution", icon: "BarChart3", divisionId: "kads-media", order: 20 },
  // KADS TECHNOLOGIES services
  { id: "web-dev", title: "Website Development", description: "Responsive, fast, and SEO-optimized websites", icon: "Globe", divisionId: "kads-tech", order: 21 },
  { id: "web-apps", title: "Web Applications", description: "Scalable web apps for complex business needs", icon: "Layout", divisionId: "kads-tech", order: 22 },
  { id: "react-dev", title: "React Development", description: "Modern component-based frontend development", icon: "Code2", divisionId: "kads-tech", order: 23 },
  { id: "nextjs-dev", title: "Next.js Development", description: "Server-side rendering and static site generation", icon: "Code2", divisionId: "kads-tech", order: 24 },
  { id: "react-native", title: "React Native Apps", description: "Cross-platform mobile apps with native feel", icon: "Smartphone", divisionId: "kads-tech", order: 25 },
  { id: "flutter", title: "Flutter Apps", description: "Beautiful apps for Android, iOS, and web", icon: "Smartphone", divisionId: "kads-tech", order: 26 },
  { id: "android", title: "Android Apps", description: "Native Android applications built with Kotlin", icon: "Smartphone", divisionId: "kads-tech", order: 27 },
  { id: "ios", title: "iOS Apps", description: "Premium iOS experiences with Swift", icon: "Smartphone", divisionId: "kads-tech", order: 28 },
  { id: "ai-dev", title: "AI Development", description: "Intelligent systems powered by machine learning", icon: "Brain", divisionId: "kads-tech", order: 29 },
  { id: "gen-ai", title: "Generative AI", description: "LLM integration and content generation systems", icon: "Brain", divisionId: "kads-tech", order: 30 },
  { id: "ml", title: "Machine Learning", description: "Predictive models and data-driven insights", icon: "Bot", divisionId: "kads-tech", order: 31 },
  { id: "chatbots", title: "Chatbots", description: "Conversational AI for customer engagement", icon: "MessageSquare", divisionId: "kads-tech", order: 32 },
  { id: "automation", title: "Automation Systems", description: "Workflow automation and process optimization", icon: "Cog", divisionId: "kads-tech", order: 33 },
  { id: "crm-dev", title: "CRM Development", description: "Custom customer relationship management tools", icon: "Users", divisionId: "kads-tech", order: 34 },
  { id: "erp-dev", title: "ERP Development", description: "Enterprise resource planning solutions", icon: "Server", divisionId: "kads-tech", order: 35 },
  { id: "admin-panels", title: "Admin Panels", description: "Powerful internal management dashboards", icon: "Layout", divisionId: "kads-tech", order: 36 },
  { id: "dashboards", title: "Dashboard Systems", description: "Real-time analytics and reporting platforms", icon: "BarChart3", divisionId: "kads-tech", order: 37 },
  { id: "backend-apis", title: "Backend APIs", description: "Robust REST and GraphQL API development", icon: "Server", divisionId: "kads-tech", order: 38 },
  { id: "cloud-solutions", title: "Cloud Solutions", description: "AWS, Firebase, and scalable cloud infrastructure", icon: "Cloud", divisionId: "kads-tech", order: 39 },
  { id: "database-design", title: "Database Design", description: "Optimized PostgreSQL, MongoDB, and vector databases", icon: "Database", divisionId: "kads-tech", order: 40 },
  { id: "maintenance", title: "Maintenance", description: "Ongoing support, updates, and bug fixes", icon: "Wrench", divisionId: "kads-tech", order: 41 },
  { id: "consulting", title: "Technical Consulting", description: "Architecture guidance and technology strategy", icon: "MessageSquare", divisionId: "kads-tech", order: 42 }
]

export const defaultProcess: ProcessStep[] = [
  // KADS MEDIA process
  { id: "media-research", step: "01", title: "Research", description: "Market analysis and audience insights", divisionId: "kads-media", order: 1 },
  { id: "media-planning", step: "02", title: "Planning", description: "Strategy and campaign architecture", divisionId: "kads-media", order: 2 },
  { id: "media-creation", step: "03", title: "Creation", description: "Content production and design", divisionId: "kads-media", order: 3 },
  { id: "media-launch", step: "04", title: "Launch", description: "Campaign execution across channels", divisionId: "kads-media", order: 4 },
  { id: "media-optimization", step: "05", title: "Optimization", description: "Continuous performance improvements", divisionId: "kads-media", order: 5 },
  { id: "media-growth", step: "06", title: "Growth", description: "Scaling successful strategies", divisionId: "kads-media", order: 6 },
  // KADS TECHNOLOGIES process
  { id: "tech-analysis", step: "01", title: "Requirement Analysis", description: "Deep discovery of business needs and goals", divisionId: "kads-tech", order: 7 },
  { id: "tech-planning", step: "02", title: "Planning", description: "Architecture, roadmap, and project scoping", divisionId: "kads-tech", order: 8 },
  { id: "tech-design", step: "03", title: "UI Design", description: "User-centered design and prototyping", divisionId: "kads-tech", order: 9 },
  { id: "tech-dev", step: "04", title: "Development", description: "Agile engineering with modern stack", divisionId: "kads-tech", order: 10 },
  { id: "tech-testing", step: "05", title: "Testing", description: "QA, security, and performance validation", divisionId: "kads-tech", order: 11 },
  { id: "tech-deployment", step: "06", title: "Deployment", description: "Cloud launch and CI/CD pipelines", divisionId: "kads-tech", order: 12 },
  { id: "tech-maintenance", step: "07", title: "Maintenance", description: "Monitoring and continuous improvements", divisionId: "kads-tech", order: 13 },
  { id: "tech-improvement", step: "08", title: "Continuous Improvement", description: "Iterative enhancement and scaling", divisionId: "kads-tech", order: 14 }
]

export const defaultIndustries: Industry[] = [
  { id: "ind-education", title: "Education", icon: "GraduationCap", divisionId: "kads-media", order: 1 },
  { id: "ind-healthcare", title: "Healthcare", icon: "HeartPulse", divisionId: "kads-media", order: 2 },
  { id: "ind-retail", title: "Retail", icon: "ShoppingBag", divisionId: "kads-media", order: 3 },
  { id: "ind-restaurants", title: "Restaurants", icon: "UtensilsCrossed", divisionId: "kads-media", order: 4 },
  { id: "ind-real-estate", title: "Real Estate", icon: "Home", divisionId: "kads-media", order: 5 },
  { id: "ind-startups", title: "Startups", icon: "Rocket", divisionId: "kads-media", order: 6 },
  { id: "ind-creators", title: "Creators", icon: "UserCircle", divisionId: "kads-media", order: 7 },
  { id: "ind-ecommerce", title: "E-Commerce", icon: "ShoppingCart", divisionId: "kads-media", order: 8 }
]

export const defaultDivisionPortfolio: PortfolioItem[] = [
  // KADS MEDIA portfolio
  { id: "dp-1", title: "EduReach Brand Campaign", category: "Branding", description: "Complete brand identity and launch campaign for an education startup.", stats: "Brand recognition +45%", details: "Designed and launched a complete brand system including logo, visual identity, social media creatives, and performance campaigns.", divisionId: "kads-media", order: 1, gradient: "from-blue-600 to-blue-800" },
  { id: "dp-2", title: "HealthPlus Social Growth", category: "Social Media", description: "Organic and paid social strategy for healthcare brand.", stats: "4x engagement", details: "Built a content calendar, managed community, and ran targeted ads across Meta and Instagram.", divisionId: "kads-media", order: 2, gradient: "from-indigo-600 to-purple-800" },
  { id: "dp-3", title: "RetailMax Festive Ads", category: "Advertising", description: "Festive performance campaign across Google and Meta.", stats: "5x ROAS", details: "Created a multi-channel campaign with compelling creatives and optimized bidding strategies.", divisionId: "kads-media", order: 3, gradient: "from-cyan-600 to-blue-800" },
  { id: "dp-4", title: "FoodHub Reel Series", category: "Content", description: "Short-form video series for food delivery brand.", stats: "2M+ views", details: "Produced a reel series with trending formats and performance tracking.", divisionId: "kads-media", order: 4, gradient: "from-blue-700 to-indigo-900" },
  { id: "dp-5", title: "PropSpace Lead Gen", category: "Lead Generation", description: "Qualified lead generation campaign for real estate.", stats: "3x qualified leads", details: "Ran targeted lead generation campaigns with landing pages and CRM integration.", divisionId: "kads-media", order: 5, gradient: "from-slate-700 to-blue-900" },
  { id: "dp-6", title: "CreatorLaunch Growth", category: "Marketing", description: "Growth marketing for creator economy platform.", stats: "10K+ signups", details: "Developed a growth strategy with influencer partnerships, SEO, and paid acquisition.", divisionId: "kads-media", order: 6, gradient: "from-blue-500 to-indigo-700" }
]

export const defaultDivisionTestimonials: Testimonial[] = [
  { id: "dt-1", name: "Ankit Sharma", role: "Founder, EduReach", text: "KADS MEDIA transformed our digital presence. Our social engagement grew 4x in just three months.", rating: 5, division: "KADS Media", company: "EduReach", order: 1 },
  { id: "dt-2", name: "Priya Patel", role: "Marketing Head, HealthPlus", text: "The team's creative strategy and performance marketing expertise delivered exceptional ROI.", rating: 5, division: "KADS Media", company: "HealthPlus", order: 2 },
  { id: "dt-3", name: "Rahul Gupta", role: "CEO, RetailMax", text: "Professional, responsive, and result-driven. KADS MEDIA is our trusted marketing partner.", rating: 5, division: "KADS Media", company: "RetailMax", order: 3 }
]

export const defaultPortfolio: PortfolioItem[] = [
  { id: "p-1", title: "AI Customer Support Platform", category: "ai", description: "Generative AI chatbot with RAG integration reducing support tickets by 60%.", stats: "60% faster resolution", details: "Built a comprehensive AI support platform using RAG architecture, vector databases, and LLM integration. Reduced average response time from 4 hours to 15 minutes.", divisionId: "kads-tech", order: 1, gradient: "from-blue-600 to-cyan-600" },
  { id: "p-2", title: "E-Commerce Mobile App", category: "apps", description: "Flutter-based shopping app with 100K+ downloads and 4.8 star rating.", stats: "100K+ downloads", details: "Developed a full-featured e-commerce mobile application with payment integration, real-time order tracking, and personalized recommendations.", divisionId: "kads-tech", order: 2, gradient: "from-indigo-600 to-purple-600" },
  { id: "p-3", title: "SaaS Analytics Dashboard", category: "websites", description: "Next.js enterprise dashboard with real-time data visualization.", stats: "3x user engagement", details: "Created an enterprise analytics platform with real-time data streaming, interactive charts, and role-based access control.", divisionId: "kads-tech", order: 3, gradient: "from-slate-700 to-blue-800" },
  { id: "p-4", title: "Healthcare Brand Identity", category: "branding", description: "Complete brand system for a multi-location healthcare provider.", stats: "Brand recognition +45%", details: "Designed a comprehensive brand identity including logo, color system, typography, marketing collateral, and brand guidelines.", divisionId: "kads-media", order: 4, gradient: "from-teal-600 to-blue-700" },
  { id: "p-5", title: "Retail Performance Campaign", category: "marketing", description: "Multi-channel digital campaign generating 5x return on ad spend.", stats: "5x ROAS", details: "Executed a multi-channel digital marketing campaign across Google Ads, Meta, and Instagram, optimizing for conversion and customer acquisition.", divisionId: "kads-media", order: 5, gradient: "from-purple-600 to-pink-600" },
  { id: "p-6", title: "Business Process Automation", category: "automation", description: "Workflow automation saving 200+ hours per month for operations team.", stats: "200+ hours saved", details: "Implemented end-to-end workflow automation integrating CRM, ERP, and communication tools, significantly reducing manual data entry.", divisionId: "kads-tech", order: 6, gradient: "from-blue-700 to-indigo-800" },
  { id: "p-7", title: "AI Content Generator", category: "ai", description: "LLM-powered platform for automated marketing content creation.", stats: "10x content output", details: "Built an AI content generation platform that produces SEO-optimized blog posts, social media content, and ad copies at scale.", divisionId: "kads-tech", order: 7, gradient: "from-cyan-600 to-blue-700" },
  { id: "p-8", title: "Real Estate Web Platform", category: "websites", description: "High-performance property listing platform with advanced search.", stats: "50% more leads", details: "Developed a high-performance real estate platform with advanced filters, map integration, and lead management system.", divisionId: "kads-tech", order: 8, gradient: "from-blue-800 to-slate-800" },
  { id: "p-9", title: "Food Delivery App", category: "apps", description: "React Native delivery app with live tracking and payments.", stats: "50K+ orders", details: "Created a food delivery application with real-time order tracking, multiple payment options, and restaurant management dashboard.", divisionId: "kads-tech", order: 9, gradient: "from-orange-600 to-red-700" }
]

export const defaultBlogs: BlogPost[] = [
  {
    id: "blog-1",
    title: "How AI is Transforming Customer Support in 2026",
    slug: "ai-transforming-customer-support",
    excerpt: "Discover how generative AI and RAG systems are reducing support costs while improving customer satisfaction.",
    content: "AI-powered customer support is no longer experimental...",
    author: "KADS TECHNOLOGIES",
    publishedAt: new Date().toISOString(),
    image: "./logo.png",
    tags: ["AI", "Customer Support", "Automation"],
    divisionId: "kads-tech",
    status: "published",
    order: 1
  }
]

export const defaultCareers: Career[] = [
  {
    id: "career-1",
    title: "Senior Full Stack Developer",
    department: "KADS TECHNOLOGIES",
    location: "Deoria, Uttar Pradesh (Remote option)",
    type: "full-time",
    description: "Join our engineering team to build scalable web and mobile applications for global clients.",
    requirements: ["3+ years React/Next.js experience", "Experience with Supabase or PostgreSQL", "Strong TypeScript skills"],
    benefits: ["Competitive salary", "Flexible work hours", "Learning budget"],
    createdAt: new Date().toISOString(),
    active: true,
    order: 1
  }
]

export const defaultTestimonials: Testimonial[] = [
  { id: "t-1", name: "Vikram Singh", role: "CTO, FinEdge Solutions", text: "KADS TECHNOLOGIES delivered our fintech platform ahead of schedule. The AI-powered features exceeded our expectations.", rating: 5, division: "KADS Technologies", company: "FinEdge Solutions", order: 1 },
  { id: "t-2", name: "Neha Agarwal", role: "Founder, StyleNest", text: "Our e-commerce revenue increased by 80% after KADS MEDIA took over our digital marketing. Truly result-driven team.", rating: 5, division: "KADS Media", company: "StyleNest", order: 2 },
  { id: "t-3", name: "Dr. Rajesh Kumar", role: "Director, MedCare Hospitals", text: "The brand identity and website KADS LABS created positioned us as the leading healthcare provider in our region.", rating: 5, division: "KADS LABS", company: "MedCare Hospitals", order: 3 },
  { id: "t-4", name: "Sneha Malhotra", role: "CEO, LearnSpace", text: "From mobile app development to marketing, the KADS team handled everything seamlessly. Highly recommended.", rating: 5, division: "KADS Technologies", company: "LearnSpace", order: 4 },
  { id: "t-5", name: "Arun Patel", role: "Marketing Head, PropVision", text: "Lead generation campaigns by KADS MEDIA delivered 3x qualified leads while reducing cost per acquisition by 40%.", rating: 5, division: "KADS Media", company: "PropVision", order: 5 },
  { id: "t-6", name: "Karan Mehta", role: "Founder, CloudScale", text: "The SaaS dashboard KADS TECHNOLOGIES built is fast, beautiful, and scalable. Our enterprise clients love it.", rating: 5, division: "KADS Technologies", company: "CloudScale", order: 6 }
]

export const defaultFAQs: FAQ[] = [
  { id: "faq-1", question: "What services does KADS LABS offer?", answer: "KADS LABS operates through three divisions: KADS LABS (enterprise software and digital products), KADS MEDIA (digital marketing, branding, and advertising), and KADS TECHNOLOGIES (website, mobile app, and AI development). Together, we provide end-to-end technology and marketing solutions.", category: "General", order: 1 },
  { id: "faq-2", question: "How long does a typical project take?", answer: "Project timelines vary based on scope and complexity. A marketing campaign may take 2-4 weeks, while a custom software product can take 8-16 weeks. We provide detailed timelines during the discovery phase and follow agile delivery practices.", category: "Project", order: 2 },
  { id: "faq-3", question: "Do you work with international clients?", answer: "Yes, we serve clients globally. Our team is experienced in remote collaboration, timezone management, and delivering projects across multiple countries. We use modern tools for transparent communication and project tracking.", category: "General", order: 3 },
  { id: "faq-4", question: "What technologies do you specialize in?", answer: "Our technology stack includes React, Next.js, React Native, Flutter, Node.js, Express, Python, TypeScript, Supabase, Firebase, PostgreSQL, MongoDB, Docker, AWS, and AI models from OpenAI, Claude, Gemini, and DeepSeek.", category: "Technical", order: 4 },
  { id: "faq-5", question: "Can you help with both development and marketing?", answer: "Absolutely. Many clients benefit from our combined expertise. We can build your product with KADS TECHNOLOGIES and launch it with KADS MEDIA for branding, advertising, and growth strategies.", category: "Services", order: 5 },
  { id: "faq-6", question: "What is your pricing model?", answer: "We offer flexible pricing based on project scope, including fixed-price projects, monthly retainers, and dedicated team engagements. Contact us for a custom quote based on your requirements.", category: "Pricing", order: 6 },
  { id: "faq-7", question: "Do you provide ongoing support and maintenance?", answer: "Yes, we provide long-term support, maintenance, monitoring, and continuous improvement services. We believe in building lasting partnerships with our clients beyond the initial launch.", category: "Services", order: 7 },
  { id: "faq-8", question: "How do I get started with KADS LABS?", answer: "You can get started by filling out the contact form on our website, calling us directly, or emailing founderskadslabs@gmail.com. We will schedule a free discovery call to understand your needs and propose a tailored solution.", category: "General", order: 8 }
]

export const defaultNavigation: NavLink[] = [
  { id: "nav-home", label: "Home", href: "#home", order: 1, visible: true },
  { id: "nav-about", label: "About", href: "#about", order: 2, visible: true },
  { id: "nav-divisions", label: "Divisions", href: "#divisions", order: 3, visible: true },
  { id: "nav-portfolio", label: "Portfolio", href: "#portfolio", order: 4, visible: true },
  { id: "nav-services", label: "Services", href: "#services", order: 5, visible: true },
  { id: "nav-blogs", label: "Insights", href: "#blogs", order: 6, visible: true },
  { id: "nav-careers", label: "Careers", href: "#careers", order: 7, visible: true },
  { id: "nav-contact", label: "Contact", href: "#contact", order: 8, visible: true }
]

export const defaultFooter: FooterData = {
  brandDescription: "Building smarter solutions through technology, design, and marketing. We help ambitious businesses grow faster in the digital age.",
  newsletterText: "Stay updated with our latest insights and projects.",
  copyright: "© 2026 KADS LABS. All Rights Reserved.",
  columns: [
    {
      title: "Quick Links",
      links: [
        { label: "Home", href: "#home" },
        { label: "About", href: "#about" },
        { label: "Divisions", href: "#divisions" },
        { label: "Portfolio", href: "#portfolio" },
        { label: "Services", href: "#services" },
        { label: "Contact", href: "#contact" }
      ]
    },
    {
      title: "Divisions",
      links: [
        { label: "KADS LABS", href: "#home" },
        { label: "KADS MEDIA", href: "#divisions" },
        { label: "KADS TECHNOLOGIES", href: "#services" }
      ]
    },
    {
      title: "Services",
      links: [
        { label: "AI Development", href: "#services" },
        { label: "Web Development", href: "#services" },
        { label: "Mobile Apps", href: "#services" },
        { label: "Digital Marketing", href: "#divisions" },
        { label: "Branding", href: "#divisions" },
        { label: "Cloud Solutions", href: "#services" }
      ]
    }
  ],
  legalLinks: [
    { label: "Privacy Policy", href: "#privacy" },
    { label: "Terms & Conditions", href: "#terms" },
    { label: "Careers", href: "#careers" },
    { label: "Blog", href: "#blogs" }
  ]
}

export const defaultContact: ContactInfo = {
  phone: "+91 75249 79551",
  email: "founderskadslabs@gmail.com",
  website: "www.kadslabs.com",
  address: "Tarkulwa, Deoria, Uttar Pradesh, India - 274408",
  mapEmbedUrl: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14323.123456789012!2d83.7813!3d26.1345!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3990c3f0f0f0f0f%3A0x0!2sTarkulwa%2C%20Deoria%2C%20Uttar%20Pradesh!5e0!3m2!1sen!2sin!4v1234567890123!5m2!1sen!2sin",
  workingHours: "Mon - Sat: 9:00 AM - 7:00 PM IST"
}

export const defaultSocial: SocialLink[] = [
  { id: "social-facebook", platform: "Facebook", url: "https://www.facebook.com/kadslabs", icon: "Facebook", order: 1 },
  { id: "social-instagram", platform: "Instagram", url: "https://www.instagram.com/kadslabs", icon: "Instagram", order: 2 },
  { id: "social-twitter", platform: "Twitter", url: "https://twitter.com/kadslabs", icon: "Twitter", order: 3 },
  { id: "social-linkedin", platform: "LinkedIn", url: "https://www.linkedin.com/company/kadslabs", icon: "Linkedin", order: 4 },
  { id: "social-youtube", platform: "YouTube", url: "https://www.youtube.com/@kadslabs", icon: "Youtube", order: 5 }
]

export const defaultSEO: SEO = {
  metaTitle: "KADS LABS | Building Smarter Solutions",
  metaDescription: "KADS LABS builds innovative software products, AI-powered solutions, websites, mobile applications, SaaS platforms, automation systems, and enterprise digital products.",
  keywords: "KADS LABS, KADS Media, KADS Technologies, AI solutions, software development, digital marketing, mobile apps, SaaS, enterprise software, Deoria, Uttar Pradesh, India",
  canonical: "https://www.kadslabs.com",
  twitterCard: "summary_large_image"
}

export const defaultSettings: WebsiteSettings = {
  siteName: "KADS LABS",
  tagline: "Building Smarter Solutions",
  logoUrl: "./logo.png",
  faviconUrl: "./logo.png",
  themeColor: "#2563EB",
  maintenanceMode: false,
  allowPublicContact: false,
  defaultRole: "user",
  adminEmails: "developer@krish.com",
  contactEmail: "founderskadslabs@gmail.com",
  notificationEmail: "founderskadslabs@gmail.com"
}

export const defaultAnalytics: AnalyticsSummary = {
  totalVisits: 0,
  pageViews: 0,
  leads: 0,
  lastUpdated: new Date().toISOString(),
  topPages: []
}

export const defaultSiteData: SiteData = {
  siteContent: defaultContent,
  leadership: defaultLeadership,
  team: defaultTeam,
  divisions: defaultDivisions,
  services: defaultServices,
  process: defaultProcess,
  industries: defaultIndustries,
  divisionPortfolio: defaultDivisionPortfolio,
  divisionTestimonials: defaultDivisionTestimonials,
  portfolio: defaultPortfolio,
  blogs: defaultBlogs,
  careers: defaultCareers,
  testimonials: defaultTestimonials,
  faqs: defaultFAQs,
  navigation: defaultNavigation,
  footer: defaultFooter,
  contact: defaultContact,
  social: defaultSocial,
  seo: defaultSEO,
  settings: defaultSettings,
  analytics: defaultAnalytics
}

export const SITE_DATA_KEY = "kads_site_data"

export const loadSiteDataFromStorage = (): SiteData => {
  if (typeof window === "undefined") return defaultSiteData
  try {
    const stored = safeStorage.getItem(SITE_DATA_KEY)
    if (stored) {
      const parsed = JSON.parse(stored)
      return { ...defaultSiteData, ...parsed, siteContent: { ...defaultContent, ...(parsed.siteContent || {}) } }
    }
  } catch (e) {
    console.error("Error loading site data:", e)
  }
  return defaultSiteData
}

export const saveSiteDataToStorage = (data: SiteData) => {
  if (typeof window === "undefined") return
  try {
    safeStorage.setItem(SITE_DATA_KEY, JSON.stringify({ ...data, updatedAt: Date.now() }))
  } catch (e) {
    console.error("Error saving site data:", e)
  }
}

export const sanitizeSiteData = (data: Partial<SiteData>): SiteData => {
  return {
    ...defaultSiteData,
    ...data,
    siteContent: { ...defaultContent, ...(data.siteContent || {}) }
  }
}

export const generateId = (prefix = "id") => `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`
